import os
import tkinter.messagebox
from tkinter import *
from tkinter import ttk   #stylish toolkits
from PIL import Image,ImageTk   #images dalna
from student import Student
from train import Train
from face_recognizeer import Face_Recognization
from attendance import Attendance
from Adminn import Admin
from help import Help


class Face_recognition_System:
    def __init__(self,root):
        self.root=root
        self.root.geometry("1530x710+0+0")#set geometry of root and start with x=0 and y= 0
        self.root.title("ATTENDANCE SYSTEM")

        #Image 1
        img = Image.open(r"comsats.jpg")
        img = img.resize((500,130),Image.ANTIALIAS) # convert high level image into low low level image
        self.photoimg = ImageTk.PhotoImage(img)
        #Setting the images using label
        f_lb1 = Label(self.root,image = self.photoimg)
        f_lb1.place(x=0,y=0,width=500,height=130)#place in on window

        # Image 2
        img1 = Image.open(r"main.jpg")
        img1 = img1.resize((500, 130), Image.ANTIALIAS)  # convert high level image into low low level image
        self.photoimg1 = ImageTk.PhotoImage(img1)
        # Setting the image using label
        f_lb1 = Label(self.root, image=self.photoimg1)
        f_lb1.place(x=500, y=0, width=500, height=130)  #

        # Image 3
        img2 = Image.open(r"img3.jpg")
        img2= img2.resize((500, 130), Image.ANTIALIAS)  # convert high level image into low low level image
        self.photoimg2 = ImageTk.PhotoImage(img2)
        # Setting the image using label
        f_lb1 = Label(self.root, image=self.photoimg2)
        f_lb1.place(x=1000, y=0, width=500, height=130)  #



        #Background Image
        img3 = Image.open(r"back.png")
        img3 = img3.resize((1530, 710), Image.ANTIALIAS)  # convert high level image into low low level image
        self.photoimg3 = ImageTk.PhotoImage(img3)
        # Setting the image using label
        bg_image = Label(self.root, image=self.photoimg3)
        bg_image.place(x=0, y=130, width=1530, height=710)  #

        # putting the labels on the upward of background image
        title_label = Label(bg_image,text="FACE RECOGNITION ATTENDANCE SYSTEM",font=("times new roman",35,"bold italic"),
        bg="black",fg="red")
        title_label.place(x=0,y=0,width=1530,height=50)

        #BUTTON Of STUDENT
        img4 = Image.open(r"student.jpg")
        img4 = img4.resize((100, 100), Image.ANTIALIAS)  # convert high level image into low low level image
        self.photoimg4 = ImageTk.PhotoImage(img4)
        b1 = Button(bg_image,image=self.photoimg4,command=self.student_details,cursor="hand1")
        b1.place(x=200,y=100,width=100,height=100)
        b1_1 = Button(bg_image, text = "STUDENT  DETAILS",command=self.student_details, cursor="hand1",bg="black",fg="red",
                      font=("times new roman",7,"bold italic"))
        b1_1.place(x=200, y=210, width=100, height=20)

        # DETECT FACE BUTTON
        img5 = Image.open(r"FACE DETECTOR.jpg")
        img5 = img5.resize((100, 100), Image.ANTIALIAS)  # convert high level image into low low level image
        self.photoimg5 = ImageTk.PhotoImage(img5)
        b1 = Button(bg_image, image=self.photoimg5, command=self.face_data,cursor="hand1")
        b1.place(x=350, y=100, width=100, height=100)
        b1_1 = Button(bg_image, text="FACE DETECTOR",command=self.face_data, cursor="hand1", bg="black", fg="red",
                      font=("times new roman", 7, "bold italic"))
        b1_1.place(x=350, y=210, width=100, height=20)


        #ATTENDANCE FACE BUTTON
        img6 = Image.open(r"ATTENDANCE.jpg")
        img6 = img6.resize((100, 100), Image.ANTIALIAS)  # convert high level image into low low level image
        self.photoimg6 = ImageTk.PhotoImage(img6)
        b1 = Button(bg_image, image=self.photoimg6,command=self.Attendanc_data, cursor="hand1")
        b1.place(x=500, y=100, width=100, height=100)
        b1_1 = Button(bg_image, text="ATTENDANCE", cursor="hand1", bg="black", fg="red",
                      font=("times new roman", 7, "bold italic"))
        b1_1.place(x=500, y=210, width=100, height=20)


        #HELP BUTTON
        img7 = Image.open(r"HELP.jpg")
        img7 = img7.resize((100, 100), Image.ANTIALIAS)  # convert high level image into low low level image
        self.photoimg7 = ImageTk.PhotoImage(img7)
        b1 = Button(bg_image, image=self.photoimg7, command=self.Help_data,cursor="hand1")
        b1.place(x=650, y=100, width=100, height=100)
        b1_1 = Button(bg_image, text="HELP BUTTON",command=self.Help_data, cursor="hand1", bg="black", fg="red",
                      font=("times new roman", 7, "bold italic"))
        b1_1.place(x=650, y=210, width=100, height=20)



        img8 = Image.open(r"train.jpg")
        img8 = img8.resize((100, 100), Image.ANTIALIAS)  # convert high level image into low low level image
        self.photoimg8 = ImageTk.PhotoImage(img8)
        b1 = Button(bg_image, image=self.photoimg8, command=self.train_data,cursor="hand1")
        b1.place(x=200, y=300, width=100, height=100)
        b1_1 = Button(bg_image, text="TRAIN DATA",command=self.train_data, cursor="hand1", bg="black", fg="red",
                      font=("times new roman", 7, "bold italic"))
        b1_1.place(x=200, y=410, width=100, height=20)

        #PHOTOS OF STUDENTS
        img9 = Image.open(r"images.jpg")
        img9 = img9.resize((100, 100), Image.ANTIALIAS)  # convert high level image into low low level image
        self.photoimg9 = ImageTk.PhotoImage(img9)
        b1 = Button(bg_image, image=self.photoimg9,command=self.open_img, cursor="hand1")
        b1.place(x=350, y=300, width=100, height=100)
        b1_1 = Button(bg_image, text="STUDENT IMAGES", cursor="hand1", command=self.open_img,bg="black", fg="red",
                      font=("times new roman", 7, "bold italic"))
        b1_1.place(x=350, y=410, width=100, height=20)


        #DEVELOPER
        img10 = Image.open(r"developer.jpg")
        img10 = img10.resize((100, 100), Image.ANTIALIAS)  # convert high level image into low low level image
        self.photoimg10 = ImageTk.PhotoImage(img10)
        b1 = Button(bg_image, image=self.photoimg10, command=self.Admin_data,cursor="hand1")
        b1.place(x=500, y=300, width=100, height=100)
        b1_1 = Button(bg_image, text="ADMIN", cursor="hand1",command=self.Admin_data, bg="black", fg="red",
                      font=("times new roman", 7, "bold italic"))
        b1_1.place(x=500, y=410, width=100, height=20)

        #EXIT
        img11 = Image.open(r"exitt.jpg")
        img11 = img11.resize((100, 100), Image.ANTIALIAS)  # convert high level image into low low level image
        self.photoimg11 = ImageTk.PhotoImage(img11)
        b1 = Button(bg_image, image=self.photoimg10,command=self.iExit, cursor="hand1")
        b1.place(x=650, y=300, width=100, height=100)
        b1_1 = Button(bg_image, text="EXIT", cursor="hand1",command=self.iExit, bg="black", fg="red",
                      font=("times new roman", 7, "bold italic"))
        b1_1.place(x=650, y=410, width=100, height=20)


    def open_img(self):
        os.startfile("data")


    def iExit(self):
        self.iExit=tkinter.messagebox.askyesno("Face Recognization","ARE U SURE U WANT TO EXIT")
        if self.iExit>0:
            self.root.destroy()
        else:
            return




        #function on buttons
    def student_details(self):
        self.new_window=Toplevel(self.root)#inbuilt function new window main home ke opper
        self.app=Student(self.new_window)

    def train_data(self):
        self.new_window = Toplevel(self.root)  # inbuilt function new window main home ke opper
        self.app = Train(self.new_window)

    def face_data(self):
        self.new_window = Toplevel(self.root)  # inbuilt function new window main home ke opper
        self.app = Face_Recognization(self.new_window)

    def Attendanc_data(self):
        self.new_window = Toplevel(self.root)  # inbuilt function new window main home ke opper
        self.app = Attendance(self.new_window)

    def Admin_data(self):
        self.new_window = Toplevel(self.root)  # inbuilt function new window main home ke opper
        self.app = Admin(self.new_window)

    def Help_data(self):
        self.new_window = Toplevel(self.root)  # inbuilt function new window main home ke opper
        self.app = Help(self.new_window)


if __name__ == "__main__":
    root=Tk() #calling root
    obj = Face_recognition_System(root)
    root.mainloop()