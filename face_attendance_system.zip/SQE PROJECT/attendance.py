from tkinter import *
from tkinter import ttk   #stylish toolkits
from PIL import Image,ImageTk   #images dalna
from tkinter import  messagebox
import mysql.connector
import cv2 as cv
import os
import csv
from tkinter import filedialog
mydata=[]#empty list to fetch data from csv to table

class Attendance:
    def __init__(self,root):
        self.root=root
        self.root.geometry("1530x710")#set geometry of root and start with x=0 and y= 0
        self.root.title("ATTENDANCE SYSTEM")


        ####variables
        self.attend_id=StringVar()
        self.attend_roll = StringVar()
        self.attend_name = StringVar()
        self.attend_dep= StringVar()
        self.attend_time = StringVar()
        self.attend_date = StringVar()
        self.attend_attendance  = StringVar()

        # Image 1
        img = Image.open(r"std1.jpg")
        img = img.resize((800, 200), Image.ANTIALIAS)  # convert high level image into low low level image
        self.photoimg = ImageTk.PhotoImage(img)
        # Setting the images using label
        f_lb1 = Label(self.root, image=self.photoimg)
        f_lb1.place(x=0, y=0, width=750, height=200)  # placin on window

        # Image 2
        img1 = Image.open(r"std2.jpg")
        img1 = img1.resize((800, 200), Image.ANTIALIAS)  # convert high level image into low low level image
        self.photoimg1 = ImageTk.PhotoImage(img1)
        # Setting the image using label
        f_lb1 = Label(self.root, image=self.photoimg1)
        f_lb1.place(x=750, y=0, width=800, height=200)  #

        img3 = Image.open(r"back.png")
        img3 = img3.resize((1530, 710), Image.ANTIALIAS)  # convert high level image into low low level image
        self.photoimg3 = ImageTk.PhotoImage(img3)
        # Setting the image using label
        bg_image = Label(self.root, image=self.photoimg3)
        bg_image.place(x=0, y=200, width=1530, height=710)  #

        title_label = Label(bg_image, text="ATTENDANCE SYSTEM",
                            font=("times new roman", 35, "bold italic"),
                            bg="orange", fg="black")
        title_label.place(x=0, y=0, width=1530, height=45)

        main_frame = Frame(bg_image, bd=2, bg="dark blue")
        main_frame.place(x=2, y=48, width=1500, height=600)

        #left label
        Left_frame = LabelFrame(main_frame, bd=2, bg="dark blue", relief=RIDGE, text="Student Attendence Details"
                                , font=("times new roman", 12, "bold"))  # BORFER STLE RIDGE
        Left_frame.place(x=5, y=0, width=650, height=514)
        img1_left = Image.open(r"STDEN.jpg")
        img1_left = img1_left.resize((720, 130), Image.ANTIALIAS)  # convert high level image into low low level image
        self.photoimg_left = ImageTk.PhotoImage(img1_left)
        f_lb1 = Label(Left_frame, image=self.photoimg_left)
        f_lb1.place(x=5, y=0, width=630, height=130)

        left_inside_frame = Frame(Left_frame, bd=2,relief=RIDGE, bg="dark blue")
        left_inside_frame.place(x=0, y=135, width=640, height=280)

        #labek entry
        #ATTENDANCE ID
        AttendanceID_label = Label(left_inside_frame, text="AttendanceID:", bg="dark blue",
                                font=("times new roman", 12, "bold"))
        AttendanceID_label.grid(row=0, column=0, padx=10)

        AttendanceID_label_entry = ttk.Entry(left_inside_frame,textvariable=self.attend_id, width=20,
                                    font=("times new roman", 10, "italic"))
        AttendanceID_label_entry.grid(row=0, column=1, padx=10, pady=5, sticky=W)

        #roll
        rollLabel_label = Label(left_inside_frame, text="Reg:", bg="dark blue",
                                   font=("times new roman", 12, "bold"))
        rollLabel_label.grid(row=0, column=2, padx=10,pady=8)

        atten_roll = ttk.Entry(left_inside_frame, width=20,textvariable=self.attend_roll,
                                             font=("times new roman", 10, "italic"))
        atten_roll.grid(row=0, column=3, pady=8, sticky=W)

        #name
        nameLabel_label = Label(left_inside_frame, text="Name:", bg="dark blue",
                                font=("times new roman", 12, "bold"))
        nameLabel_label.grid(row=1, column=0, padx=10, pady=8)

        atten_name_roll = ttk.Entry(left_inside_frame, textvariable=self.attend_name,width=20,
                               font=("times new roman", 10, "italic"))
        atten_name_roll.grid(row=1, column=1, pady=8, sticky=W)

        #dep

        depLabel_label = Label(left_inside_frame, text="Department:", bg="dark blue",
                                font=("times new roman", 12, "bold"))
        depLabel_label.grid(row=1, column=2)

        atten_dep = ttk.Entry(left_inside_frame, width=20,textvariable=self.attend_dep,
                               font=("times new roman", 10, "italic"))
        atten_dep.grid(row=1, column=3, pady=8, sticky=W)

        #time
        time_label = Label(left_inside_frame, text="Time:", bg="dark blue",
                                font=("times new roman", 12, "bold"))
        time_label.grid(row=2, column=0, padx=10, pady=8)

        atten_time = ttk.Entry(left_inside_frame, width=20,textvariable=self.attend_time,
                               font=("times new roman", 10, "italic"))
        atten_time.grid(row=2, column=1, pady=8, sticky=W)

        #date
        date_label = Label(left_inside_frame, text="Date:", bg="dark blue",
                                font=("times new roman", 12, "bold"))
        date_label.grid(row=2, column=2, padx=10, pady=8)

        atten_date = ttk.Entry(left_inside_frame, width=20,textvariable=self.attend_date,
                               font=("times new roman", 10, "italic"))
        atten_date.grid(row=2, column=3, pady=8, sticky=W)


        #attendance
        attendance_label = Label(left_inside_frame, text="Attendance Status:", bg="dark blue",
                           font=("times new roman", 12, "bold"))
        attendance_label.grid(row=3,column=0)

        self.atten_status=ttk.Combobox(left_inside_frame,textvariable=self.attend_attendance,width=15,font=("times new roman", 10, "italic"),state="readonly")
        self.atten_status["values"]=("Status","Present","Absent")
        self.atten_status.grid(row=3,column=1,padx=8)
        self.atten_status.current(0)


        #buttons
        # buttonsframe
        btn_frame = Frame(left_inside_frame, bd=2, relief=RIDGE, bg="Dark blue")
        btn_frame.place(x=0, y=200, width=633, height=35)
        save_btn = Button(btn_frame, text="Import csv",command=self.importCSV,  width=17, height=1,
                          font=("times new roman", 13, "italic"), bg="red", fg="black")
        save_btn.grid(row=0, column=0)

        update_btn = Button(btn_frame, text="Export Csv",command=self.exportCSV, width=17, height=1,
                            font=("times new roman", 13, "italic"), bg="red",
                            fg="black")
        update_btn.grid(row=0, column=1)

        delete_btn = Button(btn_frame, text="Update", width=17, height=1,
                            font=("times new roman", 13, "italic"), bg="red",
                            fg="black")
        delete_btn.grid(row=0, column=2)

        reset_btn = Button(btn_frame, text="Reset", command=self.reset_data,width=17, height=1,
                           font=("times new roman", 13, "italic"), bg="red",
                           fg="black")
        reset_btn.grid(row=0, column=3)

        #right label frame
        right_frame = LabelFrame(main_frame, bd=2, bg="dark blue", relief=RIDGE, text="Attendance"
                                 , font=("times new roman", 12, "bold"))  # BORFER STLE RIDGE
        right_frame.place(x=680, y=0, width=650, height=514)

        table_frame = Frame(right_frame, bd=2, relief=RIDGE, bg="Dark blue")
        table_frame.place(x=5, y=5, width=620, height=400)

        ##scrooll baar
        scroll_x = ttk.Scrollbar(table_frame,orient=HORIZONTAL)
        scroll_y = ttk.Scrollbar(table_frame, orient=VERTICAL)

        self.AttendanceReportTable=ttk.Treeview(table_frame,column=("id","rollno","name","department","time","date","attendance"),xscrollcommand=scroll_x.set,yscrollcommand=scroll_y.set)#headers of tables
        scroll_x.pack(side=BOTTOM,fill=X)
        scroll_y.pack(side=RIGHT, fill=Y)

        scroll_x.config(command=self.AttendanceReportTable.xview)
        scroll_y.config(command=self.AttendanceReportTable.yview)

        self.AttendanceReportTable.heading("id",text="Attendance ID")
        self.AttendanceReportTable.heading("rollno", text="REG NO")
        self.AttendanceReportTable.heading("name", text="NAME")
        self.AttendanceReportTable.heading("department", text="Department")
        self.AttendanceReportTable.heading("time", text="Time")
        self.AttendanceReportTable.heading("date", text="Date")
        self.AttendanceReportTable.heading("attendance", text="Attendance")

        self.AttendanceReportTable["show"]="headings"

        self.AttendanceReportTable.column("id",width=100)
        self.AttendanceReportTable.column("rollno", width=100)
        self.AttendanceReportTable.column("name", width=100)
        self.AttendanceReportTable.column("department", width=100)
        self.AttendanceReportTable.column("time", width=100)
        self.AttendanceReportTable.column("date", width=100)
        self.AttendanceReportTable.column("attendance", width=100)

        self.AttendanceReportTable.pack(fil=BOTH,expand=1)
        self.AttendanceReportTable.bind("<ButtonRelease>",self.get_cursor)

    ####fetch data
    def fetchData(self,rows):#attendance report table is name of table
        self.AttendanceReportTable.delete(*self.AttendanceReportTable.get_children())
        for i in rows:
            self.AttendanceReportTable.insert("",END,values=i)
    def importCSV(self):
        global mydata
        mydata.clear()
        filename=filedialog.askopenfilename(initialdir=os.getcwd(), title="Open CsV", filetypes=(("CSV FILE","*.csv"),("All file","*.*")),parent = self.root)
        with open(filename) as myfile:#reference myfile
            csvread = csv.reader(myfile,delimiter=",")
            for i in csvread:
                mydata.append(i)
            self.fetchData(mydata)

    #export csv
    def exportCSV(self):
        try:#check if there is any data or not
            if len(mydata)<1:
                messagebox.showerror("No data","No Data found to export",parent=self.root)
                return False
            filename = filedialog.asksaveasfilename(initialdir=os.getcwd(), title="Open CsV",
                                              filetypes=(("CSV FILE", "*.csv"), ("All file", "*.*")), parent=self.root)
            with open(filename,mode="w",newline="") as myfile:
                exp_write=csv.writer(myfile,delimiter=",")
                for i in mydata:
                    exp_write.writerow(i)
                messagebox.showinfo("Data Export","Your Data exported to "+os.path.basename(filename)+"successfuly")
        except Exception as es:
            messagebox.showerror("ERROR", f" due to :{str(es)}",parent = self.root)

    def get_cursor(self,event=""):
        cursor_row=self.AttendanceReportTable.focus()
        content=self.AttendanceReportTable.item(cursor_row)
        rows = content['values']
        self.attend_id.set(rows[0])
        self.attend_roll.set(rows[1])
        self.attend_name.set(rows[2])
        self.attend_dep.set(rows[3])
        self.attend_time.set(rows[4])
        self.attend_date.set(rows[5])
        self.attend_attendance.set(rows[6])


    def reset_data(self):
        self.attend_id.set("")
        self.attend_roll.set("")
        self.attend_name.set("")
        self.attend_dep.set("")
        self.attend_time.set("")
        self.attend_date.set("")
        self.attend_attendance.set("")


if __name__ == "__main__":
    root=Tk() #calling root
    obj =Attendance(root)
    root.mainloop()