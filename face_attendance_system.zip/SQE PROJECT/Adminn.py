from tkinter import *
from tkinter import ttk   #stylish toolkits
from PIL import Image,ImageTk   #images dalna
from tkinter import  messagebox
import mysql.connector
import cv2 as cv


class Admin:
    def __init__(self,root):
        self.root=root
        self.root.geometry("1530x790+0+0")#set geometry of root and start with x=0 and y= 0
        self.root.title("ATTENDANCE SYSTEM")

        title_label = Label(self.root, text="Admin Panel",
                            font=("times new roman", 35, "bold italic"),
                            bg="black", fg="red")
        title_label.place(x=0, y=0, width=1530, height=50)

        img1_top = Image.open(r"train2.jpg")
        img1_top = img1_top.resize((1530, 710), Image.ANTIALIAS)  # convert high level image into low low level image
        self.photoimg_top = ImageTk.PhotoImage(img1_top)
        f_lb1 = Label(self.root, image=self.photoimg_top)
        f_lb1.place(x=0, y=50, width=1530, height=710)
        #frame
        main_frame = Frame(f_lb1, bd=2, bg="dark blue")
        main_frame.place(x=900, y=-2, width=500, height=600)

        img1_top1 = Image.open(r"admin.jpg")
        img1_top1 = img1_top1.resize((200, 200), Image.ANTIALIAS)  # convert high level image into low low level image
        self.photoimg_top1 = ImageTk.PhotoImage(img1_top1)
        f_lb1 = Label(main_frame, image=self.photoimg_top1)
        f_lb1.place(x=240, y=0, width=200, height=200)


        #admin info
        year_label = Label(main_frame, text="Hello My name is TALH K and", bg="dark blue", font=("times new roman", 12, "bold"))
        year_label.place(x=0,y=5)
        year_label = Label(main_frame, text="Im a Software Engineer", bg="dark blue",
                           font=("times new roman", 12, "bold"))
        year_label.place(x=0, y=40)

        img1 = Image.open(r"std2.jpg")
        img1 = img1.resize((500, 390), Image.ANTIALIAS)  # convert high level image into low low level image
        self.photoimg1 = ImageTk.PhotoImage(img1)
        # Setting the image using label
        f_lb1 = Label(main_frame, image=self.photoimg1)
        f_lb1.place(x=0, y=210, width=500, height=390)


if __name__ == "__main__":
    root=Tk() #calling root
    obj = Admin(root)
    root.mainloop()