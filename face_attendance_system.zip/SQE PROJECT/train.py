from tkinter import *
from tkinter import ttk   #stylish toolkits
from PIL import Image,ImageTk   #images dalna
from tkinter import  messagebox
import mysql.connector
import cv2 as cv
import os
import numpy as np


class Train:
    def __init__(self,root):
        self.root=root
        self.root.geometry("1530x710+0+0")#set geometry of root and start with x=0 and y= 0
        self.root.title("ATTENDANCE SYSTEM")

        title_label = Label(self.root, text="DATA SET TRAINING",
                            font=("times new roman", 35, "bold italic"),
                            bg="black", fg="red")
        title_label.place(x=0, y=0, width=1530, height=50)




        img1_top = Image.open(r"train2.jpg")
        img1_top = img1_top.resize((1530,325), Image.ANTIALIAS)  # convert high level image into low low level image
        self.photoimg_top = ImageTk.PhotoImage(img1_top)
        f_lb1 = Label(self.root, image=self.photoimg_top)
        f_lb1.place(x=0, y=50, width=1530, height=300)

        b1_1 = Button(self.root, text="Train Data",command=self.train_classifier, cursor="hand1", bg="yellow",
                      fg="red",
                      font=("times new roman", 30, "bold italic"))
        b1_1.place(x=0, y=330, width=1530, height=70)

        img1_bottom = Image.open(r"train2.jpg")
        img1_bottom = img1_top.resize((1530, 325), Image.ANTIALIAS)  # convert high level image into low low level image
        self.photoimg_bottom = ImageTk.PhotoImage(img1_bottom)
        f_lb1 = Label(self.root, image=self.photoimg_bottom)
        f_lb1.place(x=0, y=400, width=1530, height=300)


    def train_classifier(self):
        data_dir = ("data")
        path = [os.path.join(data_dir,file) for file in os.listdir(data_dir)]

        faces=[]
        ids=[]
        for image in path:
            img = Image.open(image).convert("L")#Gray scale convert
            imageNp = np.array(img,"uint8")
            id = int(os.path.split(image)[1].split(".")[1])
            #D:\SQEPROJECT\data\user.1.1.jpg
           # 0                       1
            faces.append(imageNp)
            ids.append(id)
            cv.imshow("training",imageNp)
            cv.waitKey(1)==13
        ids = np.array(ids)
        #####training classifer LBPH ALGO
        clf = cv.face.LBPHFaceRecognizer_create()
        clf.train(faces,ids)
        clf.write("classifer.xml")#data write in this file train data7
        cv.destroyAllWindows()
        messagebox.showinfo("Result","Training data set completed")



if __name__ == "__main__":
    root=Tk() #calling root
    obj = Train(root)
    root.mainloop()