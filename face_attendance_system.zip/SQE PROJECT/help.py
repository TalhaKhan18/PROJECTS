from tkinter import *
from tkinter import ttk   #stylish toolkits
from PIL import Image,ImageTk   #images dalna
from tkinter import  messagebox
import mysql.connector
import cv2 as cv


class Help:
    def __init__(self,root):
        self.root=root
        self.root.geometry("1530x790+0+0")#set geometry of root and start with x=0 and y= 0
        self.root.title("ATTENDANCE SYSTEM")


        title_label = Label(self.root, text="Help Panel",
                            font=("times new roman", 35, "bold italic"),
                            bg="black", fg="red")
        title_label.place(x=0, y=0, width=1530, height=50)

        img1_top = Image.open(r"train2.jpg")
        img1_top = img1_top.resize((1530, 710), Image.ANTIALIAS)  # convert high level image into low low level image
        self.photoimg_top = ImageTk.PhotoImage(img1_top)
        f_lb1 = Label(self.root, image=self.photoimg_top)
        f_lb1.place(x=0, y=50, width=1530, height=710)

        year_label = Label(f_lb1, text="Email:tk99035@gmail.com", bg="dark blue",
                           font=("times new roman", 12, "bold"))
        year_label.place(x=570, y=250)
if __name__ == "__main__":
    root=Tk() #calling root
    obj = Help(root)
    root.mainloop()