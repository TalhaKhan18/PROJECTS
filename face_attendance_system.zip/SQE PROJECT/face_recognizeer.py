from tkinter import *
from tkinter import ttk   #stylish toolkits
from PIL import Image,ImageTk   #images dalna
from tkinter import  messagebox
import mysql.connector
import cv2 as cv
from time import strftime
from datetime import datetime
import os
import numpy as np


class Face_Recognization:
    def __init__(self,root):
        self.root=root
        self.root.geometry("1530x710")#set geometry of root and start with x=0 and y= 0
        self.root.title("Face Recognization SYSTEM")

        title_label = Label(self.root, text="Face Recognizer",
                            font=("times new roman", 35, "bold italic"),
                            bg="black", fg="red")
        title_label.place(x=0, y=0, width=1530, height=50)

        img1_top = Image.open(r"rec2.jpg")
        img1_top = img1_top.resize((1530, 710), Image.ANTIALIAS)  # convert high level image into low low level image
        self.photoimg_top = ImageTk.PhotoImage(img1_top)
        f_lb1 = Label(self.root, image=self.photoimg_top)
        f_lb1.place(x=0, y=50, width=1530, height=710)



        b1_1 = Button(f_lb1, text="Face Recognizer",command=self.face_recog, cursor="hand1", bg="yellow",
                      fg="red",
                      font=("times new roman", 20, "bold italic"))
        b1_1.place(x=1050, y=570, width=200, height=40)


    #mark attendance
    def mark_attendance(self,i,r,n,d):
        with open("TALHA.csv","r+",newline="\n") as f:
            myDatalist=f.readlines()
            name_list=[]
            for line in myDatalist:
                entry=line.split((","))
                name_list.append(entry[0])
            if((i not in name_list) and (r not in name_list) and (n not in name_list) and (d not in name_list)):# repeated attendance na lage
                now=datetime.now()
                d1=now.strftime("%d/%m/%Y")
                dtString=now.strftime("%H:%M:%S")
                f.writelines(f"\n{i},{r},{n},{d},{dtString},{d1},Present")


    def face_recog(self):#two functions because do not repeat yself
        def draw_boundary(img,classifier,scalefactor,minimumNeighbor,color,text,clf):
            grey_image = cv.cvtColor(img,cv.COLOR_BGR2GRAY)
            features = classifier.detectMultiScale(grey_image,scalefactor,minimumNeighbor)
            coord=[]
            for(x,y,w,h) in features:#drawing rectangles
                cv.rectangle(img,(x,y),(x+w,y+w),(0,255,0),3)
                id,predict = clf.predict(grey_image[y:y+h,x:x+h])#predicting model training images
                confidence = int((100*(1-predict/300)))#formula
                conn = mysql.connector.connect(host='localhost',
                                               database='mywebb',
                                               user='root',
                                                password='imTalha18')
                my_cursor = conn.cursor()
                my_cursor.execute("select Name from student where Student_id="+str(id))
                n = my_cursor.fetchone()
                n="+".join(n)

                my_cursor.execute("select Roll from student where Student_id=" + str(id))
                r = my_cursor.fetchone()
                r = "+".join(r)

                my_cursor.execute("select Dep from student where Student_id=" + str(id))
                d = my_cursor.fetchone()
                d = "+".join(d)

                my_cursor.execute("select Student_id from student where Student_id=" + str(id))
                i = my_cursor.fetchone()
                i = "+".join(i)


                if confidence>77:#confidence of training sample recognize
                    cv.putText(img, f"ID:{i}", (x, y - 75), cv.FONT_ITALIC, 0.8, (255, 255, 255), 3)
                    cv.putText(img,f"Roll:{r}",(x,y-55),cv.FONT_ITALIC,0.8,(255,255,255),3)
                    cv.putText(img, f"Name:{n}", (x, y - 30), cv.FONT_ITALIC, 0.8, (255, 255, 255), 3)
                    cv.putText(img, f"Department:{d}", (x, y - 5), cv.FONT_ITALIC, 0.8, (255, 255, 255), 3)
                    self.mark_attendance(i,r,n,d)
                else:
                    cv.rectangle(img,(x, y), (x + w, y + w), (0,0, 255), 3)
                    cv.putText(img,"UnKNOWN fACE", (x, y - 5), cv.FONT_ITALIC, 0.8, (255, 255, 255), 3)
                coord=[x,y,w,y]

            return coord
        def recognize(img,clf,faceCasscade):#two classifer lbph and facecasscade(training wala)
            coord=draw_boundary(img,faceCasscade,1.1,10,(255,255,255),"face",clf)
            return img
        faceCasscade = cv.CascadeClassifier("haarcascade_frontalface_default.xml")#two algo detection and algo
        clf = cv.face.LBPHFaceRecognizer_create()
        clf.read("classifer.xml")
        video_cap = cv.VideoCapture(0)
        while True:
            ret,img = video_cap.read()
            img = recognize(img,clf,faceCasscade)
            cv.imshow("Welcome To FAce Recognization",img)
            if cv.waitKey(1)==13:
                break
        video_cap.release()
        cv.destroyAllWindows()







if __name__ == "__main__":
    root=Tk() #calling root
    obj = Face_Recognization(root)
    root.mainloop()
